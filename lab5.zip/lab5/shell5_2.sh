#Write a shell script to check if the input string is a palindrome.
read str;
revstr=$(rev<<<$str) 
echo $revstr
if [ $str == $revstr ]
then
echo palindrome it is
else
echo not a palindrome
fi
