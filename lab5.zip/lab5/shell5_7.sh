read c
ls $c*
