#Write a shell script to accept a number in the command line and displays the sum
#up to that number. By default, the sum up to 50 should be displayed.
j=` `
if [ $1 == $j ]
then
s1=` expr 50 / 2 `
s2=` expr $s1 \* 51 `
echo $s2
else
n2=` expr $1 + 1 `
if [ ` expr $1 % 2 ` == 0 ]
then
n3=` expr $1 / 2 `
n4=` expr $n2 \* $n3 `
else
n3=` expr $n2 / 2 `
n4=` expr $1 \* $n3 `
fi 
fi
echo $n4;

