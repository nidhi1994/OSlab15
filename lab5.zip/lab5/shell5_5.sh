#Write a shell script to accept two filenames and check if both exist. If the second
#filename exists, then the contents of the first filename should be appended to it. If
#the second filename does not exist then create a newfile with the contents of the
#first file.
read fil1
read fil2
if [ -e $fil1 -a -e $fil2 ]
then
cat $fil1>>$fil2
else 
cat $fil1>$fil2
fi 
