#Write a Shell script to accept a string as command line argument and reverse the same.
rev<<<$1;
