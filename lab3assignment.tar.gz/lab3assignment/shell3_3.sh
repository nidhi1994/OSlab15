echo $"Enter n1"
read n1;
echo $"Enter n2"
read n2;
echo $"Enter choice"
echo $"1.sum+"
echo $"2.multiplication*"
echo $"3.division/"
echo $"4.subtraction-"
echo $"5.modulo%"
read ch;
if [ $ch = 1 ]
then
echo ` expr $n1 + $n2 `;
elif [ $ch = 2 ]
then
echo ` expr $n1 \* $n2 `;
elif [ $ch = 3 ]
then
echo  `expr $n1 / $n2`;
elif [ $ch = 4 ]
then
echo `expr $n1 - $n2`;
elif [ $ch = 5 ]
then
echo `expr $n1 % $n2`;
else
echo $"Enter from 1-5";
fi

