a=` expr $1 + $1 `
s=` expr $1 - $1 `
m=` expr $1 \* $1 `
d=` expr $1 / $1 `
mo=` expr $1 % $1 `
echo $a
echo $s
echo $m
echo $d
echo $mo
