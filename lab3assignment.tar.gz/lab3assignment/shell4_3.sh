echo $"Enter n1"
read n1;
echo $"Enter n2"
read n2;
if [[ "$n1" -eq "$n2" ]]
then
echo $"equal"
elif [[ "$n1" -ge "$n2" ]]
then
echo $n1
elif [[ "$n2" -ge "$n1" ]]
then
echo $n2
fi
