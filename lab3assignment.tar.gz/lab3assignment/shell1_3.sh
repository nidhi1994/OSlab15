echo $"Enter n1"
read n1;
echo $"Enter n2"
read n2;
echo ` expr $n1 + $n2 `;
echo ` expr $n1 \* $n2 `;
echo  `expr $n1 / $n2`;
echo `expr $n1 - $n2`;
echo `expr $n1 % $n2`;


