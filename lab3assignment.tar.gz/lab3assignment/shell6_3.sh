echo $"Enter a command"
read c;
$c;

