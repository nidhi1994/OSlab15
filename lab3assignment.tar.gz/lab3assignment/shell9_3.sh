echo $"what is capital of Gujarat"
read c
while [ $c != "gandhinagar" ]
do
	echo $"what is capital of Gujarat"
	read c
done
