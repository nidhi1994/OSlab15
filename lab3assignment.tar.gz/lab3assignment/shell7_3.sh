read m;
if [ $m = "Jan" ]
then
echo $"January"
elif [ $m = "Janu" ]
then
echo $"January"
elif [ $m = "Janua" ]
then
echo $"January"
elif [ $m = "January" ]
then
echo $"January"
fi
