n[0]=1
n[1]=2
n[2]=5
n[3]=9
n[4]=0
n[5]=10
read m
for (( i=0;i<6;i++ ))
do
if[ $m = n(i) ]
then
n=1
echo $"present"	
echo -n "$i"
fi
done
if [ $n -ne 1 ]
then
echo $"not present"

