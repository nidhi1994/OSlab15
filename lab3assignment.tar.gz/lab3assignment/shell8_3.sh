read n;
num="$n"
a=0
b=1
for (( i=0;i<=num;i++ ))
do
	echo -n "$a"
	c=$((a+b))
	a=$b
	b=$c
done

