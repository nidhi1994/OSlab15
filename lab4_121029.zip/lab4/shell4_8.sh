#Write a shell script to count number of newline characters in a file.
wc -l temp.txt 
#echo $b
#read str
#l=grep wc "." $str
#echo $l
