read s
b= grep $s f1.txt
if [ $? -eq 0 ]
then
echo found
else
echo not found
fi
