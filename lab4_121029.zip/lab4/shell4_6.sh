t=$(date +"%H")
if [ $t -ge 6 -a $t -le 12 ]
then
echo Good Morning
elif [ $t -gt 12 -a $t -le 16 ]
then
echo Good afternoon
elif [ $t -gt 16 -a $t -le 20 ]
then
echo Good evening
else
echo Good night
fi
