read n;
if [ ` expr $n % 2 ` == 0 ]
then
n2=` expr $n + 1 `
n3=` expr $n / 2 `
n4=` expr $n2 \* $n3 `
else
n2=` expr $n + 1 `
n3=` expr $n2 / 2 `
n4=` expr $n \* $n3 `
fi
echo $n4;



