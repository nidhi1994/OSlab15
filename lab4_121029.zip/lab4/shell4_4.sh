read n;
f=0;
if [ $n -eq 1 ]
then
echo neither prime nor composite
fi
n1=$((n/2));
num=$((n1+1));
for (( i=1 ; i < $num ; i++ ))
do
	echo modulo	
	echo ` expr $n % $i `	
	if [ ` expr $n % $i ` -eq 0 ]
	then
	echo s
	f=$((f+1));
	echo $f
	fi
done
if [ $f -eq 1 ]
then
echo prime
else
echo composite
fi
