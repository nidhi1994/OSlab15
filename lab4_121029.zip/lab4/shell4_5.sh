read b;
if [ $b -gt 1500 ]
then
echo 500
else
n=` expr $b \* 10 `;
echo ` expr $n / 100 `
fi
